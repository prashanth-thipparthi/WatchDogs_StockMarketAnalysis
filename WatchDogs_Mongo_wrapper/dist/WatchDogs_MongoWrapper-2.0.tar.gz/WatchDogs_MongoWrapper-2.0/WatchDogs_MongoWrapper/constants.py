### Mongo Constants
class Constants():
    def __init__(self):
        self.mongo_username = 'bigData'
        self.mongo_password = 'swdtrDdTGBB96kz'
        self.mongo_external_ip = '104.197.77.55'
        self.mongo_db_name = 'TweetDB'
        self.mongo_tweets_collection_name = 'Tweets'
        self.mongo_stocks_collection_name = 'Stocks'
